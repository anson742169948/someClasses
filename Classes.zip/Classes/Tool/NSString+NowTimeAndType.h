//
//  NSString+NowTimeAndType.h
//  CityManage
//
//  Created by 菲王 on 16/3/24.
//  Copyright © 2016年 exsun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (NowTimeAndType)

+(NSString *) stringWithNowTimeForFileType:(NSString*) fileTYPE;
@end
