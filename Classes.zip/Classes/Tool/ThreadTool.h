//
//  ThreadTool.h
//  BasicClass
//
//  Created by 菲王 on 16/3/3.
//  Copyright © 2016年 WangFei. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ThreadTool : NSObject


typedef void(^MyBlock)(void);

/**
 并行线程后台执行（不可刷新UI）
 **/
+(void) asyncBackgroupBlock:(MyBlock) doSomethingBlock;
/**
 并行线程主线程执行（可以刷新UI）
 **/
+(void) asyncMainBlock:(MyBlock) doSomethingBlock;
/**
 串行线程后台执行，待Block执行完毕后才返回（不可刷新UI）
 **/
+(void) syncBackgroupBlock:(MyBlock) doSomethingBlock;
/**
 串行线程主线程执行，待Block执行完毕后才返回（可以刷新UI）
 **/
+(void) syncMainBlock:(MyBlock) doSomethingBlock;
/**
 延迟delay秒后，将Block添加到主线程任务队列,并执行（可以刷新UI）
 **/
+(void) afterSencond:(double) delay toDoMainThreadBlock:(MyBlock) doSomething;
@end

