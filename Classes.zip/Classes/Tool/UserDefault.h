//
//  UserDefault.h
//  CityManage
//
//  Created by Exsun on 16/3/17.
//  Copyright © 2016年 exsun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserDefault : NSObject

//
+(NSString *) retrunToken;
//
+(void)settingApptoken:(NSString *) token;
//
+(NSString *) retrunVersion;
//
+(void)settingVersion:(NSString *) Version;
//
+(void) reload;
@end
