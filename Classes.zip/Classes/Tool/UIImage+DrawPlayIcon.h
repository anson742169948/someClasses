//
//  UIImage+DrawPlayIcon.h
//  CityManage
//
//  Created by Exsun on 16/3/16.
//  Copyright © 2016年 exsun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (DrawPlayIcon)
+(UIImage *) drawPlayIconOnImage:(UIImage *) image;
@end
