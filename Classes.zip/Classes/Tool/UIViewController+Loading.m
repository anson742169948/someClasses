//
//  UIViewController+Loading.m
//  CityManage
//
//  Created by 菲王 on 16/3/24.
//  Copyright © 2016年 exsun. All rights reserved.
//

#import "UIViewController+Loading.h"
#import "SVProgressHUD.h"
@implementation UIViewController (Loading)

-(void)showLoadingWithText:(NSString *)text{
    [SVProgressHUD showWithStatus:text];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [SVProgressHUD dismiss];
    });
}


@end
