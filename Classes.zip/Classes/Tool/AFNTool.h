//
//  AFNTool.h
//  BasicClass
//
//  Created by 王菲 on 16/2/16.
//  Copyright © 2016年 WangFei. All rights reserved.
//
/**
 *  封装AFNetworking的工具方法，请在Podfile中添加下列方法
 *  pod 'AFNetworking', '~> 3.0.4'
 *
 */
#import <Foundation/Foundation.h>
#import "AFNetworking.h"
/**
 *  网络请求返回值
 *
 *  @param result 返回的结果
 *  @param status 返回的状态
 *  @param error  错误提示
 */
typedef void (^ReturnValueBlock)(id result,NSInteger status,NSString *error);

typedef NS_ENUM(NSInteger,NetMethodState) {
    NetMethodHttpGET = 1,
    NetMethodHttpPOSt
};

@interface AFNTool : NSObject




@property(nonatomic,assign,readonly)BOOL networkError;

/**
 *  检查网络状态
 */
+(void) toolNetworkingStatusCheck;

/**
 *  选择方式
 *
 *  @param state            请求方式：NetMethodHttpPOSt或者NetMethodHttpGET
 *  @param url              请求链接
 *  @param parameter        参数包
 *  @param returnValueBlock 返回解析后的Block
 */

+(void) toolRequestWithlMethod:(NetMethodState) state URL:(NSString *)url Parameter:(NSDictionary *)parameter CallBack:(ReturnValueBlock)returnValueBlock;



@end
