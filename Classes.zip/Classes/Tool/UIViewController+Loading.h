//
//  UIViewController+Loading.h
//  CityManage
//
//  Created by 菲王 on 16/3/24.
//  Copyright © 2016年 exsun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (Loading)

-(void) showLoadingWithText:(NSString *)text;


@end
