//
//  NetworkTool.m
//  JiaPei
//
//  Created by Exsun on 16/4/18.
//  Copyright © 2016年 Exsun. All rights reserved.
//

#import "NetworkTool.h"
#import <AFNetworking.h>
@interface NetworkTool()

@property(nonatomic,assign)BOOL networkError;


@end
@implementation NetworkTool

#pragma mark - 单例
DEFINE_SINGLETON_FOR_CLASS(NetworkTool)

+ (void)toolNetworkingStatus {
    [[NetworkTool sharedNetworkTool] netWorkStatusCheck];
}

- (void)netWorkStatusCheck {
    self.networkError = NO;
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        /*
         AFNetworkReachabilityStatusUnknown          = -1,  // 未知
         AFNetworkReachabilityStatusNotReachable     = 0,   // 无连接
         AFNetworkReachabilityStatusReachableViaWWAN = 1,   // 3G 花钱
         AFNetworkReachabilityStatusReachableViaWiFi = 2,   // WiFi
         */
        switch (status) {
            case -1:
                NSLog(@"未知问题");
                self.networkError = YES;
                break;
                
            case 0:
                NSLog(@"无网络连接");
                self.networkError = YES;
                break;
            case 1:
                NSLog(@"使用流量上网");
                self.networkError = NO;
                break;
            case 2:
                NSLog(@"使用WiFi上网");
                self.networkError = NO;
                break;
        }
    }];
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];

}

- (void)GetRequesWithMethod:(NSString *)url Parameter:(NSDictionary *)parameter CallBack:(ReturnDicBlock)returnDicBlock {
//    if (self.networkError == YES) {
//        NSLog(@"网络有问题");
//        returnDicBlock(nil,@"网络有问题");
//    }
    AFHTTPSessionManager *manger = [AFHTTPSessionManager manager];
    [manger GET:url parameters:parameter progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        returnDicBlock(responseObject,nil);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        returnDicBlock(nil,error);
    }];
    
    
}

- (void)POSTRequesWithMethod:(NSString *)url Parameter:(NSDictionary *)parameter CallBack:(ReturnDicBlock)returnDicBlock {
    
    AFHTTPSessionManager *manger = [AFHTTPSessionManager manager];
    
    [manger POST:url parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        returnDicBlock(responseObject,nil);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        returnDicBlock(nil,error);
    }];
    
}
@end
