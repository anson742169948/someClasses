//
//  UIImage+DrawPlayIcon.m
//  CityManage
//
//  Created by Exsun on 16/3/16.
//  Copyright © 2016年 exsun. All rights reserved.
//

#import "UIImage+DrawPlayIcon.h"

@implementation UIImage (DrawPlayIcon)
+(UIImage *)drawPlayIconOnImage:(UIImage *)image{
    
    return nil;
}
@end
