//
//  ThreadTool.m
//  BasicClass
//
//  Created by 菲王 on 16/3/3.
//  Copyright © 2016年 WangFei. All rights reserved.
//

#import "ThreadTool.h"

@implementation ThreadTool
+(void) asyncBackgroupBlock:(MyBlock)doSomethingBlock{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        doSomethingBlock();
    });
}
+(void) asyncMainBlock:(MyBlock)doSomethingBlock{
    dispatch_async(dispatch_get_main_queue(), ^{
        doSomethingBlock();
    });
}
+(void) syncBackgroupBlock:(MyBlock)doSomethingBlock{
    dispatch_sync(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        doSomethingBlock();
    });
}
+(void) syncMainBlock:(MyBlock)doSomethingBlock{
    dispatch_sync(dispatch_get_main_queue(), ^{
        doSomethingBlock();
    });
}
+(void) afterSencond:(double)delay toDoMainThreadBlock:(MyBlock)doSomething{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        doSomething();
    });
}
@end
