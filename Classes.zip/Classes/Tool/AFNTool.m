//
//  AFNTool.m
//  BasicClass
//
//  Created by 王菲 on 16/2/16.
//  Copyright © 2016年 WangFei. All rights reserved.
//
#import "JPPrefixHeader.pch"
#import "AFNTool.h"
#import "SynthesizeSingleton.h"
#define Defaults [NSUserDefaults standardUserDefaults]
@interface AFNTool ()


@property(nonatomic,assign)BOOL networkError;


@end

@implementation AFNTool

#pragma mark - 单例

DEFINE_SINGLETON_FOR_CLASS(AFNTool)

#pragma mark - CheckNetworkingState
+(void) toolNetworkingStatusCheck{
    [[AFNTool sharedAFNTool] netWorkStatusCheck];
}
-(void)netWorkStatusCheck{
    self.networkError = NO;
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        /**
         AFNetworkReachabilityStatusUnknown          = -1,  // 未知
         AFNetworkReachabilityStatusNotReachable     = 0,   // 无连接
         AFNetworkReachabilityStatusReachableViaWWAN = 1,   // 3G 花钱
         AFNetworkReachabilityStatusReachableViaWiFi = 2,   // WiFi
         */
        switch (status) {
            case -1:
                NSLog(@"未知问题");
                self.networkError = YES;
                break;
            case 0:
                NSLog(@"无网络连接");
                self.networkError = YES;
                break;
            case 1:
                NSLog(@"使用移动流量");
                self.networkError = NO;
                break;
            case 2:
                NSLog(@"使用Wi-Fi流量");
                self.networkError = NO;
                break;
            default:
                break;
        }
    }];
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];

}

#pragma mark - ChooseNetMethod

+(void) toolRequestWithlMethod:(NetMethodState) state URL:(NSString *)url Parameter:(NSDictionary *)parameter CallBack:(ReturnValueBlock)returnValueBlock{
    switch (state) {
        case NetMethodHttpGET:{
            [[AFNTool sharedAFNTool] getRequestWithURL:url Parameter:parameter CallBack:returnValueBlock];
            break;
        }
        case NetMethodHttpPOSt:{
            [[AFNTool sharedAFNTool] postRequestWithURL:url Parameter:parameter CallBack:returnValueBlock];
            break;
        }
        default:
            break;
    }
}


#pragma mark - GET Method

-(void) getRequestWithURL:(NSString *)url Parameter:(NSDictionary *)parameter CallBack:(ReturnValueBlock)returnValueBlock{
    if (self.networkError == YES) {
        NSLog(@"网络有问题");
        returnValueBlock(nil,0,@"网络有问题");
        return;
    }
    AFHTTPSessionManager *manager = [self SettingManager];
    [manager GET:url parameters:parameter progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSString *string = [self checkResponseObjectWith:responseObject];
        if (!string) {
            returnValueBlock(nil,0,@"数据源无法正确解析");
            return ;
        }
        returnValueBlock(string,1,nil);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"error: %@", error);
        returnValueBlock(nil,0,error.description);
    }];
}

#pragma mark - POST Method


-(void) postRequestWithURL:(NSString *)url Parameter:(NSDictionary *)parameter CallBack:(ReturnValueBlock)returnValueBlock{
    if (self.networkError == YES) {
        NSLog(@"网络有问题");
        returnValueBlock(nil,0,@"网络有问题");
        return;
    }
    AFHTTPSessionManager *manager = [self SettingManager];
    [manager POST:url parameters:parameter progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSString *string = [self checkResponseObjectWith:responseObject];
        if (!string) {
            returnValueBlock(nil,0,@"数据源无法正确解析");
            return ;
        }
        id result = [self checkResultWithString:string];
        if (!result) {
            returnValueBlock(nil,0,@"result解析失败！");
            return;
        }
        returnValueBlock(result,1,nil);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"error: %@", error);
        returnValueBlock(nil,0,error.description);
    }];
}


#pragma mark - HTTP Defult Setting

-(AFHTTPSessionManager *) SettingManager{
    AFHTTPSessionManager *manager = [[AFHTTPSessionManager alloc] initWithBaseURL:[NSURL URLWithString:API_Basic_URL] sessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    /**
     *  request设置
     */
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [manager.requestSerializer setValue:@"iOS" forHTTPHeaderField:@"AppType"];
    [manager.requestSerializer setValue:[UserDefault retrunToken] forHTTPHeaderField:@"AppToken"];
    /**
     *  response设置
     */
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/html",@"text/json", @"text/javascript", nil];
    return manager;
}




//
#pragma mark - Check Result orResponseObjece
-(NSString *) checkResponseObjectWith:(id) responseObject{
    if (![responseObject isKindOfClass:[NSDictionary class]]) {
        NSLog(@"解析失败");
        return nil;
    }
    if ([responseObject valueForKey:@"success"] == 0) {
        NSLog(@"错误内容＝＝%@，错误代码＝＝%@",[responseObject valueForKey:@"msg"],[responseObject valueForKey:@"ReturnCode"]);
        return nil;
    }
    NSString *string = [responseObject valueForKey:@"success"];
    return string;
}


-(id) checkResultWithString:(NSString *)string{
    NSError *error;
    NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
    id result = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
    if (error) {
        NSLog(@"解析失败");
        return nil;
    }
    return result;
}

@end
