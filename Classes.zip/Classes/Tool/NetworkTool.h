/**
*
 * ━━━━━━ 神兽出没━━━━━━
 * 　  　 ┏┓ 　┏┓
 * 　  　┏┛┻━━━┛┻┓
 * 　  　┃　　 　┃
 * 　  　┃　 　　┃
 * 　  　┃　┳┛ ┗┳┃
 * 　  　┃　 　　┃
 * 　  　┃　　┻　┃
 * 　  　┃ 　　　┃
 * 　  　┗━┓ 　┏━┛
 * 　　　　┃ 　┃
 * 　　　　┃ 　┃
 * 　　　　┃　 ┗━━━┓
 * 　　　　┃　 　　┣┓
 * 　　　　┃ 　　　┏┛
 * 　　　　┗┓┓┏━┳┓┏┛
 * 　　　　 ┃┫┫　┃┫┫
 * 　　　 　┗┻┛　┗┻┛
 *
 * ━━━━━━ 保佑无Bug ━━━━━━
*/


//
//  NetworkTool.h
//  JiaPei
//
//  Created by Exsun on 16/4/18.
//  Copyright © 2016年 Exsun. All rights reserved.
//

#import <Foundation/Foundation.h>
/**
 *  网络请求返回值
 *
 *  @param result 返回的数据包（字典）
 *  @param error  错误提示
 */
typedef void(^ReturnDicBlock)(NSDictionary *result,NSError *error);

@interface NetworkTool : NSObject

@property(nonatomic,assign,readonly)BOOL networkError;

/**
 *  检查网络状态
 */
+ (void)toolNetworkingStatus;

- (void)GetRequesWithMethod:(NSString *)url Parameter:(NSDictionary *)parameter CallBack:(ReturnDicBlock)returnDicBlock;

- (void)POSTRequesWithMethod:(NSString *)url Parameter:(NSDictionary *)parameter CallBack:(ReturnDicBlock)returnDicBlock;



@end
