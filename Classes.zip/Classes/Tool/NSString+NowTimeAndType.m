//
//  NSString+NowTimeAndType.m
//  CityManage
//
//  Created by 菲王 on 16/3/24.
//  Copyright © 2016年 exsun. All rights reserved.
//

#import "NSString+NowTimeAndType.h"

@implementation NSString (NowTimeAndType)
+(NSString *) stringWithNowTimeForFileType:(NSString*) fileTYPE{
    NSDate *date = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"YYYY-MM-DD-HH-MM"];
    NSString *locationString = [dateFormatter stringFromDate:date];
    return [locationString stringByAppendingString:fileTYPE];
}
@end
