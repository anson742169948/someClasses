//
//  UserDefault.m
//  CityManage
//
//  Created by Exsun on 16/3/17.
//  Copyright © 2016年 exsun. All rights reserved.
//

#import "UserDefault.h"
#define Defaults [NSUserDefaults standardUserDefaults]
@implementation UserDefault 


+(NSString *) retrunToken{
    return [Defaults valueForKey:@"AppToken"];
}

+(void)settingApptoken:(NSString *) token{
    [Defaults setValue:token forKey:@"AppToken"];
}


+(NSString *) retrunVersion{
    return [Defaults valueForKey:@"Version"];
}

+(void)settingVersion:(NSString *) Version{
    [Defaults setValue:Version forKey:@"Version"];
}


+(void) reload{
    [Defaults synchronize];
}

@end
