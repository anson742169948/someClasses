//
//  JsonUtils.m
//  Ticket-ios
//
//  Created by linhongwei on 15/9/2.
//  Copyright (c) 2015年 LHW. All rights reserved.
//

#import "JsonUtils.h"
#import "objc/runtime.h"

@implementation JsonUtils

+(NSDictionary *)getObjectData:(id)object
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    unsigned int propsCount;
    objc_property_t *props = class_copyPropertyList([object class], &propsCount);
    for (int i = 0; i < propsCount; i++) {
        objc_property_t prop = props[i];
        
        NSString *propName = [NSString stringWithUTF8String:property_getName(prop)];
        id value = [object valueForKey:propName];
        
        if (value == nil) {
            value = [NSNull null];
        } else {
            value = [self getObjectInternal:value];
            
        }
        [dic setObject:value forKey:propName];
        
    }
    return dic;
}

+ (id)getObjectInternal:(id)obj
{
    if([obj isKindOfClass:[NSString class]]
       || [obj isKindOfClass:[NSNumber class]]
       || [obj isKindOfClass:[NSNull class]])
    {
        return obj;
    }
    
    if([obj isKindOfClass:[NSArray class]])
    {
        NSArray *objarr = obj;
        NSMutableArray *arr = [NSMutableArray arrayWithCapacity:objarr.count];
        for(int i = 0;i < objarr.count; i++)
        {
            [arr setObject:[self getObjectInternal:[objarr objectAtIndex:i]] atIndexedSubscript:i];
        }
        return arr;
    }
    
    if([obj isKindOfClass:[NSDictionary class]])
    {
        NSDictionary *objdic = obj;
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithCapacity:[objdic count]];
        for(NSString *key in objdic.allKeys)
        {
            [dic setObject:[self getObjectInternal:[objdic objectForKey:key]] forKey:key];
        }
        return dic;
    }
    return [self getObjectData:obj];
}

+(NSDictionary*)readJSONfile:(NSString *)path complete:(ReadCompleteBlock)complete
{
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSError *error;
    NSDictionary *jsonObject;
    if (data) {
        jsonObject = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
    }else{
        printf("****** Json data is nil! ****** \n");
    }
    
    if (complete) {
        complete();
    }
    
    return jsonObject;
}

+(NSDictionary *)readJSONData:(NSData *)data complete:(ReadCompleteBlock)complete
{
    NSError *error;
    NSDictionary *jsonObject = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
    assert(!error);
    
    if (complete) {
        complete();
    }
    
    return jsonObject;
}

+(NSDictionary *)readJSONObject:(id)object options:(NSJSONWritingOptions)options error:(NSError *__autoreleasing *)error
{
    NSData *objectData = [NSJSONSerialization dataWithJSONObject:object options:options error:error];
    
    
    return [self readJSONData:objectData complete:nil];
}

@end
