//
//  BaseHandler.h
//  Ticket-ios
//
//  Created by linhongwei on 15/9/2.
//  Copyright (c) 2015年 LHW. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CommonCrypto/CommonCrypto.h>
#import "PXAlertView.h"

/**
 *  Handler处理完成后调用的Block
 */
typedef void (^CompleteBlock)();

/**
 *  Handler处理成功时调用的Block
 *
 *  @param obj id type
 */
typedef void (^SuccessBlock)(id obj);

/**
 *  Handler处理失败时调用的Block
 *
 *  @param obj id type
 */
typedef void (^FailedBlock)(id obj);

@interface BaseHandler : NSObject

+(NSString *)getMD5_32Bit_String:(NSString *)srcString;

+(id)combineDictionary:(id)dicOne withDictionary:(id)dicTwo;

+ (UIImage *)scaleImage:(UIImage *)image scaledToSize:(CGSize)size;

+ (UIImage *) createImageWithColor: (UIColor*) color;

+ (void) autosizeLabel:(UILabel*)label withFont:(UIFont *)font andString:(NSString *)str;

+ (NSString *) jointStrings:(NSArray*)strings;

+ (void)backToLogin:(UIViewController *)controller;

+(UIImage *)fullScreenshots;

+(UIImage *)viewScreenshots:(UIView*)oneView;

+(BOOL)isHaveChineseOrNum:(NSString *)str;

+(BOOL)isHaveChinese:(NSString *)str;

+(BOOL)isValidateEmail:(NSString *)email;

//  将数组重复的对象去除，只保留一个
+ (NSArray *)arrayWithMemberIsOnly:(NSArray *)array;

//  只保留数组重复对象的其中一个，其他去除
+ (NSArray *)arrayWithMemberFilterNotOnly:(NSArray *)array;

+(void)writeImgWithURL:(NSString*)url imageName:(NSString*)img success:(SuccessBlock)success;

+(NSString *)URLEncodedString:(NSString *)str;

+(NSString *)URLDecodedString:(NSString *)str;

+ (BOOL)isAllowedNotification;

//拼音、中文 模糊搜索
+ (NSArray *)userFuzzySearch:(NSArray *)dataArray keyStr:(NSString *)key;

+ (NSString *)makeupFlightTimeRange:(NSArray*)times;

//提示框方法
+(void)showOneBtnPXAlertViewWithTitle:(NSString*)title message:(NSString*)msg cancelTitle:(NSString*)cancel canDismissed:(BOOL)canDismissed completion:(PXAlertViewCompletionBlock)completion;

+(void)showTwoBtnPXAlertViewWithTitle:(NSString*)title message:(NSString*)msg cancelTitle:(NSString*)cancel otherTitle:(NSString*)other canDismissed:(BOOL)canDismissed completion:(PXAlertViewCompletionBlock)completion;

+(void)showOneBtnPXAlertViewWithTitle:(NSString *)title message:(NSString *)msg msgAlignment:(NSTextAlignment)alignment cancelTitle:(NSString *)cancel canDismissed:(BOOL)canDismissed completion:(PXAlertViewCompletionBlock)completion;

+(void)showTwoBtnPXAlertViewWithTitle:(NSString *)title message:(NSString *)msg msgAlignment:(NSTextAlignment)alignment cancelTitle:(NSString *)cancel otherTitle:(NSString *)other canDismissed:(BOOL)canDismissed completion:(PXAlertViewCompletionBlock)completion;

+(UIColor*)colorWithHexString:(NSString*)hex alpha:(float)alpha;

//tableView滚动到某一行
+(void)scroolTableView:(UITableView*)tableView rowObject:(id)obj withDataSource:(NSArray*)data;

//将某个view的长宽按x/y缩放
+(void)makeScale:(UIView*)view sx:(CGFloat)x sy:(float)y;

+(NSString*)getIPWithHostName:(const NSString *)hostName;

//显示指示器
+(void)showHUD;

+(void)showHUDwithWords:(NSString*)words;

//隐藏指示器
+(void)hideHUD;
//时间戳转换NSDate
+(NSDate*)dateFromUnixTimeStamp:(NSTimeInterval)timeStamp;

+(UIImage*)blurryImage:(UIImage*)image withBlurLevel:(CGFloat)blur;

+(NSDate*)dateWithTimeStamp:(id)timeStamp;

+(NSString*)timeStampWithObj:(float)timeStamp;

//URI跳转页面
+(void)gotoViewWithCurrent:(UIViewController *)current andURI:(NSURL *)url;

//处理成功订单的数据
+(NSDictionary*)handleSuccessData:(NSDictionary*)data;

@end
