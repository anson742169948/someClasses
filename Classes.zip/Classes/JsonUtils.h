//
//  JsonUtils.h
//  Ticket-ios
//
//  Created by linhongwei on 15/9/2.
//  Copyright (c) 2015年 LHW. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^ReadCompleteBlock)();

@interface JsonUtils : NSObject

+ (NSDictionary *) getObjectData:(id)object;

+ (id)getObjectInternal:(id)obj;

/**
 *  read json file
 *
 *  @param path     path of json file
 *  @param complete the block when reading be done
 *
 *  @return dictionary
 */
+ (NSDictionary *) readJSONfile:(NSString*)path complete:(ReadCompleteBlock)complete;

/**
 *  read json data
 *
 *  @param data     json data
 *  @param complete the block when reading be done
 *
 *  @return dictionary
 */
+ (NSDictionary *) readJSONData:(NSData*)data complete:(ReadCompleteBlock)complete;

+ (NSDictionary *) readJSONObject:(id)object options:(NSJSONWritingOptions)options error:(NSError **)error;


@end
