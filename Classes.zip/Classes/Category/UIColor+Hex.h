//
//  UIColor+Hex.h
//  Ticket-ios
//
//  Created by Anson on 15/9/15.
//  Copyright (c) 2015年 LHW. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (Hex)

+(UIColor *)colorWithHexString:(NSString *)color;

+(UIColor *)colorWithHexString:(NSString *)color alpha:(CGFloat)alpha;

@end
