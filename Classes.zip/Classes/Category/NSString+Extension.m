//
//  NSString+Extension.m
//  Ticket-ios
//
//  Created by Anson on 15/11/25.
//  Copyright © 2015年 LHW. All rights reserved.
//

#import "NSString+Extension.h"

@implementation NSString (Extension)

//返回字符串所占用的尺寸.
-(CGSize)sizeWithFont:(UIFont *)font maxSize:(CGSize)maxSize
{
    NSDictionary *attrs = @{NSFontAttributeName : font};
    return [self boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:attrs context:nil].size;
}

-(BOOL)containsString:(NSString *)str
{
    if (!str || [str isEqualToString:@""]){
        return NO;
    }
    if ([self rangeOfString:str].location != NSNotFound) {
        return YES;
    }
    return NO;
}

@end
