//
//  UINavigationController+PushPop.h
//  Ticket-ios
//
//  Created by Anson on 15/12/1.
//  Copyright © 2015年 LHW. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationController (PushPop)

-(void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated tabBar:(BOOL)isHidden;

@end
