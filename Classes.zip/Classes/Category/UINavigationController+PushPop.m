//
//  UINavigationController+PushPop.m
//  Ticket-ios
//
//  Created by Anson on 15/12/1.
//  Copyright © 2015年 LHW. All rights reserved.
//

#import "UINavigationController+PushPop.h"

@implementation UINavigationController (PushPop)

-(void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated tabBar:(BOOL)isHidden
{
    viewController.hidesBottomBarWhenPushed = isHidden;
    [self pushViewController:viewController animated:animated];
}

@end
