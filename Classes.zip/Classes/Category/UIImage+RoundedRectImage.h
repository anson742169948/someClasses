//
//  UIImage+RoundedRectImage.h
//  Ticket-ios
//
//  Created by Anson on 15/9/17.
//  Copyright (c) 2015年 LHW. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (RoundedRectImage)

+ (id)createRoundedRectImage:(UIImage*)image size:(CGSize)size radius:(NSInteger)r;

@end
