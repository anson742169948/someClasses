//
//  BaseHandler.m
//  Ticket-ios
//
//  Created by linhongwei on 15/9/2.
//  Copyright (c) 2015年 LHW. All rights reserved.
//
#import "LogoViewController.h"
#import "pinyin.h"
#import "BaseHandler.h"
#import "PXAlertView+Customization.h"
#import "UINavigationController+PushPop.h"
#import "UIColor+Hex.h"
#import "Reachability.h"
#import <SystemConfiguration/SystemConfiguration.h>
#import "UIImageView+AFNetworking.h"
#import "AFNetworking.h"
#import "APIConfig.h"

#import "TicketViewController.h"
#import "NewSureOrderViewController.h"
#import "WriteBudgetViewController.h"
#import "WaitingPayViewController.h"
#import "OrderViewController.h"
#import "MessageViewController.h"
#import "PersonalViewController.h"
#import "PhoneViewController.h"
#import "ChangeOrderController.h"

#include <netdb.h>
#include <sys/socket.h>
#include <arpa/inet.h>

@implementation BaseHandler

+(NSString *)getMD5_32Bit_String:(NSString *)srcString
{
    const char *cStr = [srcString UTF8String];
    unsigned char digest[CC_MD5_DIGEST_LENGTH];
    CC_MD5(cStr, strlen(cStr), digest);
    NSMutableString *ret = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH];
    
    for (int i = 0; i < CC_MD5_DIGEST_LENGTH; i++) {
        [ret appendFormat:@"%02x",digest[i]];
    }
    return ret;
}

+(id)combineDictionary:(id)dicOne withDictionary:(id)dicTwo
{
    NSMutableDictionary *mutDic = [NSMutableDictionary dictionaryWithDictionary:dicOne];
    if (dicTwo) {
        for (int i = 0; i < [[dicTwo allKeys] count]; i++) {
            [mutDic setObject:[dicTwo objectForKey:[dicTwo allKeys][i]] forKey:[dicTwo allKeys][i]];
        }
        
    }
    return mutDic;
}

+ (UIImage *)scaleImage:(UIImage *)image scaledToSize:(CGSize)size
{
    UIGraphicsBeginImageContext(size);
    [image drawInRect:CGRectMake(0,0,size.width,size.height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return newImage;
}

+ (UIImage*) createImageWithColor: (UIColor*) color
{
    CGRect rect=CGRectMake(0,0, 1, 1);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return theImage;
}

+(void)autosizeLabel:(UILabel *)label withFont:(UIFont *)font andString:(NSString *)str
{
    if (label) {
        [label setNumberOfLines:0];
        CGSize size = CGSizeMake(320, 2000);
        CGSize lableSize = [str sizeWithFont:font constrainedToSize:size lineBreakMode:NSLineBreakByWordWrapping];
        [label setFrame:CGRectMake(0, 0, lableSize.width, lableSize.height)];
        [label setText:str];
    }
}

+(NSString *)jointStrings:(NSArray *)strings
{
    NSString *tmp = nil;
    int count = (int)[strings count];
    if (count>1) {
        for (int i = 0; i<count; i++) {
            if (i == 0) {
                tmp = [NSString stringWithFormat:@"%@",[strings objectAtIndex:i]];
            }else{
                tmp = [NSString stringWithFormat:@"%@ / %@",tmp,[strings objectAtIndex:i]];
            }
        }
        NSLog(@"TMP String:%@",tmp);
        return tmp;
    }else if (count == 1){
        return [NSString stringWithFormat:@"%@",[strings objectAtIndex:0]];
    }else{
        return @"";
    }
    
}

//退回到登录界面
+ (void)backToLogin:(UIViewController *)controller{
    
    [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"USER_UID"];
    [[NSUserDefaults standardUserDefaults]setObject:nil forKey:@"USER_SID"];
    
    id isFirst = [[NSUserDefaults standardUserDefaults]objectForKey:@"IS_FIRST_BACK"];
    if (!isFirst) {
        LogoViewController *logoView = [[LogoViewController alloc]init];
        [controller.navigationController pushViewController:logoView animated:YES];
        [[NSUserDefaults standardUserDefaults]setObject:@"yes" forKey:@"IS_FIRST_BACK"];
    }else{
        [[NSUserDefaults standardUserDefaults]setObject:@"no" forKey:@"IS_FIRST_BACK"];
        PhoneViewController *phone = [[PhoneViewController alloc]init];
        [controller.navigationController pushViewController:phone animated:YES tabBar:YES];
    }
    
}

//全屏截图，包括window
+(UIImage *)fullScreenshots{
    UIWindow *screenWindow = [[UIApplication sharedApplication] keyWindow];
    
    UIGraphicsBeginImageContext(screenWindow.frame.size);
    
    [screenWindow.layer renderInContext:UIGraphicsGetCurrentContext()];
    
    UIImage *viewImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return viewImage;
    
}

//某个view截图
+(UIImage *)viewScreenshots:(UIView*)oneView{
    UIGraphicsBeginImageContext(oneView.frame.size);
    
    [oneView.layer renderInContext:UIGraphicsGetCurrentContext()];
    
    UIImage *viewImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return viewImage;
    
}

//判断是否含有中文或者数字
+(BOOL)isHaveChineseOrNum:(NSString *)str {
    for(int i=0; i< [str length];i++){
        int a = [str characterAtIndex:i];
        if( a > 0x4e00 && a < 0x9fff)
        {
            return YES;
        }
        
    }
    
    NSString *regex = @".*[0-9].*";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    
    if ([predicate evaluateWithObject:str] == YES) {
        return YES;
    }
    
    return NO;
    
}

//是否包含中文
+(BOOL)isHaveChinese:(NSString *)str {
    for(int i=0; i< [str length];i++){
        int a = [str characterAtIndex:i];
        if( a > 0x4e00 && a < 0x9fff)
        {
            return YES;
        }
        
    }
    return NO;
    
}

//利用正则表达式验证邮箱格式
+(BOOL)isValidateEmail:(NSString *)email {
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}

+ (NSArray *)arrayWithMemberIsOnly:(NSArray *)array
{
    NSMutableArray *categoryArray = [[NSMutableArray alloc] init];
    for (unsigned i = 0; i < [array count]; i++) {
        @autoreleasepool {
            if ([categoryArray containsObject:[array objectAtIndex:i]] == NO) {
                [categoryArray addObject:[array objectAtIndex:i]];
            }
        }
    }
    return categoryArray;
}

+ (NSArray *)arrayWithMemberFilterNotOnly:(NSArray *)array
{
    NSMutableArray *categoryArray = [[NSMutableArray alloc] init];
    NSMutableArray *allArray = [[NSMutableArray alloc]init];
    for (unsigned i = 0; i < [array count]; i++) {
        @autoreleasepool {
            if ([categoryArray containsObject:[array objectAtIndex:i]] == NO) {
                [categoryArray addObject:[array objectAtIndex:i]];
            }else{
                [allArray addObject:[array objectAtIndex:i]];
            }
        }
    }
    
    return allArray;
}

+(void)writeImgWithURL:(NSString *)url imageName:(NSString *)img success:(SuccessBlock)success
{
    NSString *urlStr = [url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURLRequest *request = [[NSURLRequest alloc]initWithURL:[NSURL URLWithString:urlStr]];
    
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    NSLog(@"图片地址：%@ URL:%@",request,urlStr);
    UIApplication *app = [UIApplication sharedApplication];
    app.networkActivityIndicatorVisible =YES;//转动
    NSURLSessionDownloadTask *downloadTask = [manager downloadTaskWithRequest:request progress:nil destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *docPath = [paths objectAtIndex:0];
//        NSString *filePath = [[paths objectAtIndex:0]stringByAppendingPathComponent:img];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        if([fileManager fileExistsAtPath:docPath])//检查文件夹是否存在
        {//文件夹存在
            //NSLog(@"文件夹存在");
        }
        else
        {//文件夹不存在
            //NSLog(@"文件夹不存在");
            //创建路径
            [fileManager createDirectoryAtPath:docPath withIntermediateDirectories:YES attributes:nil error:nil];
        }
        NSURL *documentsDirectoryPath=[NSURL fileURLWithPath:docPath];
        //返回你要保存的路径
        return [documentsDirectoryPath URLByAppendingPathComponent:img];
        
//        NSData *imageData = UIImagePNGRepresentation(image);
//        
//        [imageData writeToFile:filePath atomically:YES];
    } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
        if(filePath==nil)
        {
            //图片地址空
            NSLog(@"图片地址空,request:%@",request);
            NSLog(@"error:%@",error);
        }
        else
        {
            success([filePath absoluteString]);
            NSLog(@"File downloaded to: %@", filePath);
        }
    }];
    [downloadTask resume];
    
}

+(NSString *)URLEncodedString:(NSString *)str
{
    NSString *encodedString = (NSString *)
    CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
                                                              (CFStringRef)str,
                                                              NULL,
                                                              (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                              kCFStringEncodingUTF8));
    
    return encodedString;
}

+(NSString *)URLDecodedString:(NSString *)str
{
    NSString *decodedString=(__bridge_transfer NSString *)CFURLCreateStringByReplacingPercentEscapesUsingEncoding(NULL, (__bridge CFStringRef)str, CFSTR(""), CFStringConvertNSStringEncodingToEncoding(NSUTF8StringEncoding));
    
    return decodedString;
}

+ (BOOL)isAllowedNotification
{
    
    //iOS8 check if user allow notification
    
    if (IOS8_OR_LATER) {// system is iOS8
            UIUserNotificationSettings *setting = [[UIApplication sharedApplication] currentUserNotificationSettings];
            
            if
                (UIUserNotificationTypeNone != setting.types) {
                    
                    return
                    YES;
                }
        }
    else
    {//iOS7
        UIRemoteNotificationType type = [[UIApplication sharedApplication] enabledRemoteNotificationTypes];
        
        if(UIRemoteNotificationTypeNone != type)
            
            return 
            YES;
    }
    
    
    return 
    NO;
}

//不连续搜索
+ (NSArray *)userFuzzySearch:(NSArray *)dataArray keyStr:(NSString *)key{
    NSMutableArray *searchArray = [[NSMutableArray alloc]init];
    
    if([dataArray count] < 1) return nil;
    
    NSString *searchData = @"";
    searchData = [NSString stringWithCString:[key UTF8String] encoding:NSUTF8StringEncoding];
    
    if([searchData length] > 0)
    {
        for(int i=0; i<[dataArray count];i++)
        {
            NSString *data = @"";
            
            if(![searchData canBeConvertedToEncoding:NSASCIIStringEncoding])
            {
                data = [dataArray objectAtIndex:i];
            }else
            {
                data = [dataArray objectAtIndex:i];
                NSMutableString *pinyin = [[NSMutableString alloc] init];
                for(int i=0; i<[data length];i++)
                {
                    NSString *str =[[NSString stringWithFormat:@"%c",pinyinFirstLetter([data characterAtIndex:i])] uppercaseString];
                    [pinyin appendString:str];
                }
                if([pinyin length] > 0)
                    data =  pinyin;
            }
            
            int currentLocation = 0;
            [self searchDataInString:data fullString:[dataArray objectAtIndex:i] withSearchText:searchData withLocation:currentLocation withSearchArray:searchArray];
        }
    }
    return searchArray;
}



+ (void)searchDataInString:(NSString *)data fullString:(NSString *)fullData withSearchText:(NSString *)searchText withLocation:(int)location withSearchArray:(NSMutableArray*)searchArray{
    
    if([data length] > location)
    {
        NSComparisonResult result = [data compare:searchText options:NSCaseInsensitiveSearch
                                            range:NSMakeRange(location, [searchText length])];
        if (result == NSOrderedSame)
        {
            [searchArray addObject:fullData];
        }else
        {
            location++;
            [self searchDataInString:data fullString:fullData withSearchText:searchText withLocation:location withSearchArray:searchArray];
        }
    }
}

+(NSString *)makeupFlightTimeRange:(NSArray *)times
{
    NSArray *timeArray = @[@"00:00~23:59",@"00:00~05:59",@"06:00~11:59",@"12:00~18:59",@"19:00~23:59"];
    NSArray *timeTitles = @[@"不限",@"凌晨",@"上午",@"下午",@"晚上"];
    
    NSMutableArray *tmpTitles = [[NSMutableArray alloc]init];
    
    for (NSString *obj in times) {
        for (int i = 0; i<timeArray.count; i++) {
            if ([[timeArray objectAtIndex:i]isEqualToString:obj]) {
                [tmpTitles addObject:[timeTitles objectAtIndex:i]];
            }
        }
        
    }
    
    return [BaseHandler jointStrings:tmpTitles];
}

+(void)showOneBtnPXAlertViewWithTitle:(NSString *)title message:(NSString *)msg cancelTitle:(NSString *)cancel canDismissed:(BOOL)canDismissed completion:(PXAlertViewCompletionBlock)completion
{
    [self showOneBtnPXAlertViewWithTitle:title message:msg msgAlignment:NSTextAlignmentCenter cancelTitle:cancel canDismissed:canDismissed completion:completion];
}

+(void)showTwoBtnPXAlertViewWithTitle:(NSString *)title message:(NSString *)msg cancelTitle:(NSString *)cancel otherTitle:(NSString *)other canDismissed:(BOOL)canDismissed completion:(PXAlertViewCompletionBlock)completion
{
    [self showTwoBtnPXAlertViewWithTitle:title message:msg msgAlignment:NSTextAlignmentCenter cancelTitle:cancel otherTitle:other canDismissed:canDismissed completion:completion];
}

+(void)showOneBtnPXAlertViewWithTitle:(NSString *)title message:(NSString *)msg msgAlignment:(NSTextAlignment)alignment cancelTitle:(NSString *)cancel canDismissed:(BOOL)canDismissed completion:(PXAlertViewCompletionBlock)completion
{
    PXAlertView *alert = [PXAlertView showAlertWithTitle:title
                                                 message:msg
                                             cancelTitle:cancel
                                            canDismissed:canDismissed
                                            msgAlignment:alignment
                                              completion:completion];
    
    [alert setBackgroundColor:[UIColor whiteColor]];
    [alert setTitleColor:[UIColor colorWithHexString:@"#675F6D"]];
    [alert setMessageColor:[UIColor colorWithHexString:@"#9B9B9B"]];
    [alert setMessageFont:[UIFont systemFontOfSize:13]];
    [alert setAllButtonsTextColor:[UIColor colorWithHexString:@"#32C47C"]];
    
    [alert setAllButtonsBackgroundColor:[UIColor colorWithHexString:@"#F4F4F4"]];
    [alert setAllButtonsNonSelectedBackgroundColor:[UIColor whiteColor]];
    [alert setTapToDismissEnabled:NO];
    
}

+(void)showTwoBtnPXAlertViewWithTitle:(NSString *)title message:(NSString *)msg msgAlignment:(NSTextAlignment)alignment cancelTitle:(NSString *)cancel otherTitle:(NSString *)other canDismissed:(BOOL)canDismissed completion:(PXAlertViewCompletionBlock)completion
{
    PXAlertView *alert = [PXAlertView showAlertWithTitle:title
                                                 message:msg
                                             cancelTitle:cancel
                                              otherTitle:other
                                            canDismissed:canDismissed
                                            msgAlignment:alignment
                                              completion:completion];
    [alert setVisible:YES];
    [alert setBackgroundColor:[UIColor whiteColor]];
    [alert setTitleColor:[UIColor colorWithHexString:@"#675F6D"]];
    [alert setMessageColor:[UIColor colorWithHexString:@"#9B9B9B"]];
    [alert setMessageFont:[UIFont systemFontOfSize:13]];
    [alert setAllButtonsTextColor:[UIColor colorWithHexString:@"#32C47C"]];
    
    [alert setAllButtonsBackgroundColor:[UIColor colorWithHexString:@"#F4F4F4"]];
    [alert setAllButtonsNonSelectedBackgroundColor:[UIColor whiteColor]];
    [alert setTapToDismissEnabled:NO];
    
}

+(UIColor *)colorWithHexString:(NSString *)hex alpha:(float)alpha
{
    return [UIColor colorWithHexString:hex alpha:alpha];
}

+(void)scroolTableView:(UITableView *)tableView rowObject:(id)obj withDataSource:(NSArray *)data
{
    NSInteger row = 0;
    NSInteger section = 0;
    
    if (data.count!=0) {
        for (int i = 0; i<data.count; i++) {
            NSDictionary * sectionDictionary = [data objectAtIndex:i];
            NSArray *sectionDatas = [sectionDictionary objectForKey:@"data"];
            for (int j = 0; j < sectionDatas.count; j++) {
                id tmpObj = [sectionDatas objectAtIndex:j];
                if ([tmpObj isEqual:obj]) {
                    row = j;
                    section = i;
                }
            }
            
        }
        
        if ([[[data objectAtIndex:section]objectForKey:@"indexTitle"]isEqualToString:@"热门城市"]) {
            if (tableView.numberOfSections>0) {
                [tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:YES];
            }
            
        }else{
            if (tableView.numberOfSections>section) {
                [tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:row inSection:section] atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
            }
            
        }
    }
    
    
}

+(NSString *)getIPWithHostName:(const NSString *)hostName
{
    NSArray *hosts = HOSTS;
    NSArray *ips = [[NSUserDefaults standardUserDefaults]objectForKey:@"VIABLEHOSTS"];
    if (ips&&ips.count>0) {
        hosts = ips;
    }
    
    NSArray *testHosts = @[@"121.42.162.111"];
    
    struct hostent *host = gethostbyname([hostName UTF8String]);
    if (!host) {
        herror("resolv");
        if (IS_TEST) {
            NSLog(@"IP:%@",[self testIPArray:testHosts]);
            return [self testIPArray:testHosts];
        }else{
            NSLog(@"IP:%@",[self testIPArray:hosts]);
            return [self testIPArray:hosts];
        }
        
    }
    struct in_addr **list = (struct in_addr **)host->h_addr_list;
    NSString *addressString = [NSString stringWithCString:inet_ntoa(*list[0]) encoding:NSUTF8StringEncoding];
    NSLog(@"IP:%@",addressString);
    return addressString;
}

+(NSString*)testIPArray:(NSArray*)ips
{
    if (ips.count>0) {
        Reachability *r;
        for (NSString *ip in ips) {
            const char *ipaddr = [ip UTF8String];
            struct sockaddr_in address;
            memset(&address, 0, sizeof(address));
            address.sin_len = sizeof(address);
            address.sin_family = AF_INET;
            address.sin_addr.s_addr = htons(inet_addr(ipaddr));
            r = [Reachability reachabilityWithAddress:&address];
            switch ([r currentReachabilityStatus]) {
                case NotReachable:
                    
                    break;
                default:
                    return ip;
                    break;
            }
        }
        if (IS_TEST) {
            return @"apitest.dwfei.com";
        }else{
           return @"api.dwfei.com";
        }
        
    }else{
        if (IS_TEST) {
            return @"apitest.dwfei.com";
        }else{
            return @"api.dwfei.com";
        }
    }
}

+(void)makeScale:(UIView *)view sx:(CGFloat)x sy:(float)y
{
    CGAffineTransform newTransform = CGAffineTransformScale(view.transform, x, y);
    [view setTransform:newTransform];
}

+(void)showHUD
{
    UIWindow *keyWindow = [[UIApplication sharedApplication]keyWindow];
    if (![keyWindow viewWithTag:1200]) {
        UIView *allGrayView = [[UIView alloc]initWithFrame:keyWindow.frame];
        [allGrayView setBackgroundColor:[UIColor colorWithHexString:@"#000000" alpha:0.5]];
        [allGrayView setAlpha:0.0];
        allGrayView.tag = 1201;
        [keyWindow addSubview:allGrayView];
        
        UIImageView *loadingView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 80, 80)];
        NSMutableArray *imgs = [[NSMutableArray alloc]init];
        for (int i = 1; i<121; i++) {
            UIImage *tmpImg = [UIImage imageNamed:[NSString stringWithFormat:@"loading_%i.png",i]];
            [imgs addObject:tmpImg];
        }
        [loadingView setCenter:keyWindow.center];
        loadingView.animationImages = imgs;
        loadingView.animationDuration = 4;
        loadingView.tag = 1200;
        [keyWindow addSubview:loadingView];
        [loadingView setAlpha:0.0];
    
        UILabel *loadingLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 180, 16)];
        [loadingLabel setBackgroundColor:[UIColor clearColor]];
        [loadingLabel setTextAlignment:NSTextAlignmentCenter];
        [loadingLabel setTextColor:[UIColor whiteColor]];
        [loadingLabel setFont:[UIFont systemFontOfSize:11]];
        [loadingLabel setTag:1202];
        [loadingLabel setCenter:CGPointMake(loadingView.center.x, loadingView.center.y+loadingView.frame.size.height/2+16)];
        [allGrayView addSubview:loadingLabel];
        
    }
    
    UIImageView *loadingView = [[[UIApplication sharedApplication]keyWindow]viewWithTag:1200];
    UIView *allGrayView = [[[UIApplication sharedApplication]keyWindow]viewWithTag:1201];
    UILabel *loadingLabel = [allGrayView viewWithTag:1202];
    [loadingLabel setHidden:YES];
    
    [UIView animateWithDuration:0.0 animations:^{
        [keyWindow bringSubviewToFront:allGrayView];
        [keyWindow bringSubviewToFront:loadingView];
        [loadingView setAlpha:1.0];
        [allGrayView setAlpha:1.0];
    } completion:^(BOOL finished) {
        [loadingView startAnimating];
    }];
    
//    [MBProgressHUD showHUDAddedTo:[[UIApplication sharedApplication]keyWindow] animated:YES];
}

+(void)showHUDwithWords:(NSString*)words
{
    UIWindow *keyWindow = [[UIApplication sharedApplication]keyWindow];
    if (![keyWindow viewWithTag:1200]) {
        UIView *allGrayView = [[UIView alloc]initWithFrame:keyWindow.frame];
        [allGrayView setBackgroundColor:[UIColor colorWithHexString:@"#000000" alpha:0.5]];
        [allGrayView setAlpha:0.0];
        allGrayView.tag = 1201;
        [keyWindow addSubview:allGrayView];
        
        UIImageView *loadingView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 80, 80)];
        NSMutableArray *imgs = [[NSMutableArray alloc]init];
        for (int i = 1; i<121; i++) {
            UIImage *tmpImg = [UIImage imageNamed:[NSString stringWithFormat:@"loading_%i.png",i]];
            [imgs addObject:tmpImg];
        }
        [loadingView setCenter:keyWindow.center];
        loadingView.animationImages = imgs;
        loadingView.animationDuration = 4;
        loadingView.tag = 1200;
        [keyWindow addSubview:loadingView];
        [loadingView setAlpha:0.0];
        
        UILabel *loadingLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 180, 16)];
        [loadingLabel setBackgroundColor:[UIColor clearColor]];
        [loadingLabel setTextAlignment:NSTextAlignmentCenter];
        [loadingLabel setTextColor:[UIColor whiteColor]];
        
        [loadingLabel setTag:1202];
        [loadingLabel setFont:[UIFont systemFontOfSize:11]];
        [loadingLabel setCenter:CGPointMake(loadingView.center.x, loadingView.center.y+loadingView.frame.size.height/2+16)];
        [allGrayView addSubview:loadingLabel];
        
    }
    
    UIImageView *loadingView = [[[UIApplication sharedApplication]keyWindow]viewWithTag:1200];
    UIView *allGrayView = [[[UIApplication sharedApplication]keyWindow]viewWithTag:1201];
    UILabel *loadingLabel = [allGrayView viewWithTag:1202];
    [loadingLabel setText:words];
    [loadingLabel setHidden:NO];
    [UIView animateWithDuration:0.0 animations:^{
        [keyWindow bringSubviewToFront:allGrayView];
        [keyWindow bringSubviewToFront:loadingView];
        [loadingView setAlpha:1.0];
        [allGrayView setAlpha:1.0];
    } completion:^(BOOL finished) {
        [loadingView startAnimating];
    }];
    
}

+(void)hideHUD
{
    UIImageView *loadingView = [[[UIApplication sharedApplication]keyWindow]viewWithTag:1200];
    UIView *allGrayView = [[[UIApplication sharedApplication]keyWindow]viewWithTag:1201];
    if (loadingView) {
        [UIView animateWithDuration:0.1 animations:^{
            [loadingView setAlpha:0.0];
            [allGrayView setAlpha:0.0];
        } completion:^(BOOL finished) {
            [loadingView stopAnimating];
        }];
    }
    
    
//    [MBProgressHUD hideAllHUDsForView:[[UIApplication sharedApplication]keyWindow] animated:YES];
}

+(NSDate *)dateFromUnixTimeStamp:(NSTimeInterval)timeStamp
{
    return [NSDate dateWithTimeIntervalSince1970:timeStamp];
}

+(NSDate *)dateWithTimeStamp:(id)timeStamp
{
    NSString *stamp = [NSString stringWithFormat:@"%@",timeStamp];
    return [NSDate dateWithTimeIntervalSince1970:[stamp longLongValue]/1000];
}

+(NSString*)timeStampWithObj:(float)timeStamp
{
    NSString *stamp = [NSString stringWithFormat:@"%.0f",timeStamp];
    return stamp;
}

+(UIImage *)blurryImage:(UIImage *)image withBlurLevel:(CGFloat)blur
{
    CIContext *context = [CIContext contextWithOptions:nil];
    CIImage *inputImage = [CIImage imageWithCGImage:image.CGImage];
    CIFilter *filter = [CIFilter filterWithName:@"CIGaussianBlur" keysAndValues:kCIInputImageKey,inputImage,@"inputRadius",@(blur), nil];
    CIImage *outputImage = filter.outputImage;
    CGImageRef outImage = [context createCGImage:outputImage fromRect:[outputImage extent]];
    return [UIImage imageWithCGImage:outImage];
}

+(void)gotoViewWithCurrent:(UIViewController *)current andURI:(NSURL *)url
{
    NSString *scheme = url.scheme;
    NSString *host = url.host;
    NSString *path = url.path;
    NSString *query = [BaseHandler URLDecodedString:url.query];
    
    NSLog(@"%@",url.host);
    NSLog(@"%@",url.parameterString);
    NSLog(@"%@",url.path);
    NSLog(@"%@",url.pathComponents);
    NSLog(@"Scheme: %@", [url scheme]);
    NSLog(@"Host: %@", [url host]);
    NSLog(@"Port: %@", [url port]);
    NSLog(@"Path: %@", [url path]);
    NSLog(@"Relative path: %@", [url relativePath]);
    NSLog(@"Path components as array: %@", [url pathComponents]);
    NSLog(@"Parameter string: %@", [url parameterString]);
    NSLog(@"Query: %@", [url query]);
    NSLog(@"Fragment: %@", [url fragment]);
    NSLog(@"User: %@", [url user]);
    NSLog(@"Password: %@", [url password]);
    
    if (host.length!=0) {
        if ([scheme isEqualToString:@"dwf"]) {
            id uid = [[NSUserDefaults standardUserDefaults] objectForKey:@"USER_UID"];
            NSArray *tmpArray = [query componentsSeparatedByString:@"&"];
            NSMutableDictionary *data = [[NSMutableDictionary alloc]init];
            for (NSString *str in tmpArray) {
                NSArray *array = [str componentsSeparatedByString:@"="];
                [data setObject:[array objectAtIndex:1] forKey:[array objectAtIndex:0]];
            }
            
            if([host isEqualToString:@"homepage"]){
                if ([path isEqualToString:@"/ticket"]) {
                    if (data) {
                        
                        UINavigationController *nav = (UINavigationController*)[current.tabBarController.viewControllers objectAtIndex:1];
                        TicketViewController *ticket = (TicketViewController*)[nav.viewControllers objectAtIndex:0];
                        
                        if ([[data allKeys]containsObject:@"from"]) {
                            ticket.startCitys = @[[data objectForKey:@"from"]];
                        }
                        if ([[data allKeys]containsObject:@"to"]) {
                            ticket.endCitys = @[[data objectForKey:@"to"]];
                        }
                        if ([[data allKeys]containsObject:@"isRoundTrip"]) {
                            ticket.isGoBack = [data objectForKey:@"isRoundTrip"];
                        }else{
                            ticket.isGoBack = @"YES";
                        }
                        ticket.step = StartStep;
                        ticket.isFormHome = @"YES";
                        [ticket loadDayPrice];
                        [ticket nextStep];
                        [ticket showTabbar:NO];
                        
                        [current.tabBarController setSelectedIndex:1];
                        
                    }
                    
                }else if ([path isEqualToString:@"/specialoffer"]){
                    [UmengClick event:@"sale" page:@"homepage"];
                    [current.tabBarController setSelectedIndex:2];
                }else if ([path isEqualToString:@"/hunt_ticket_order_confirm"]){
                    if (data) {
                        NSMutableDictionary *recommendParams = [[NSMutableDictionary alloc]init];
                        NSMutableDictionary *orderDetailData = [[NSMutableDictionary alloc]init];
                        
                        if ([[data allKeys]containsObject:@"durationMax"]) {
                            [recommendParams setObject:[data objectForKey:@"durationMax"] forKey:@"durationMax"];
                            [orderDetailData setObject:[data objectForKey:@"durationMax"] forKey:kOrderReformerKeyOrderDurationMax];
                        }
                        if ([[data allKeys]containsObject:@"durationMin"]) {
                            [recommendParams setObject:[data objectForKey:@"durationMin"] forKey:@"durationMin"];
                            [orderDetailData setObject:[data objectForKey:@"durationMin"] forKey:kOrderReformerKeyOrderDurationMin];
                        }
                        if ([[data allKeys]containsObject:@"startTo"]) {
                            [recommendParams setObject:[data objectForKey:@"startTo"] forKey:@"endDate"];
                            
                            NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
                            [formatter setDateFormat:@"yyyy-MM-dd"];
                            NSDate *tmpDate = [formatter dateFromString:[data objectForKey:@"startTo"]];
                            long long stamp = [tmpDate timeIntervalSince1970]*1000;
                            [orderDetailData setObject:[NSNumber numberWithLongLong:stamp] forKey:kOrderReformerKeyOrderDepartureTimeMax];
                        }
                        if ([[data allKeys]containsObject:@"from"]) {
                            [recommendParams setObject:@[[data objectForKey:@"from"]] forKey:@"fromLocs"];
                            [orderDetailData setObject:@[[data objectForKey:@"from"]] forKey:kOrderReformerKeyOrderFromLoc];
                        }
                        if ([[data allKeys]containsObject:@"isRoundTrip"]) {
                            [recommendParams setObject:[data objectForKey:@"isRoundTrip"] forKey:@"roundTrip"];
                            [orderDetailData setObject:[data objectForKey:@"isRoundTrip"] forKey:kOrderReformerKeyOrderRoundTrip];
                        }
                        if ([[data allKeys]containsObject:@"startFrom"]) {
                            [recommendParams setObject:[data objectForKey:@"startFrom"] forKey:@"startDate"];
                            
                            NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
                            [formatter setDateFormat:@"yyyy-MM-dd"];
                            NSDate *tmpDate = [formatter dateFromString:[data objectForKey:@"startFrom"]];
                            long long stamp = [tmpDate timeIntervalSince1970]*1000;
                            [orderDetailData setObject:[NSNumber numberWithLongLong:stamp] forKey:kOrderReformerKeyOrderDepartureTimeMin];
                        }
                        if ([[data allKeys]containsObject:@"to"]) {
                            [recommendParams setObject:@[[data objectForKey:@"to"]] forKey:@"toLocs"];
                            [orderDetailData setObject:@[[data objectForKey:@"to"]] forKey:kOrderReformerKeyOrderToLoc];
                        }
                        if ([[data allKeys]containsObject:@"recommendedPrice"]){
                            [orderDetailData setObject:[data objectForKey:@"recommendedPrice"] forKey:kOrderReformerKeyOrderUnitPrice];
                        }
                        
                        ChangeOrderController *changeOrder = [[ChangeOrderController alloc]init];
                        changeOrder.isFromHome = YES;
                        changeOrder.isFromSearch = YES;
                        [changeOrder setInfoDic:orderDetailData];
                        [changeOrder loadRecommendPrice:recommendParams];
                        [current.navigationController pushViewController:changeOrder animated:YES];
                    }
                }else if ([path isEqualToString:@"/realtime_flightlist"]){
                    
                    if (data) {
                        WriteBudgetViewController *bugetController = [[WriteBudgetViewController alloc]init];
                        NSMutableDictionary *tmp = [[NSMutableDictionary alloc]init];
                        if ([[data allKeys]containsObject:@"from"]) {
                            [tmp setObject:@[[data objectForKey:@"from"]] forKey:@"fromLocs"];
                        }
                        if ([[data allKeys]containsObject:@"to"]) {
                            [tmp setObject:@[[data objectForKey:@"to"]] forKey:@"toLocs"];
                        }
                        if ([[data allKeys]containsObject:@"startFrom"]) {
                            [tmp setObject:[data objectForKey:@"startFrom"] forKey:@"startDate"];
                        }
                        if ([[data allKeys]containsObject:@"startTo"]) {
                            [tmp setObject:[data objectForKey:@"startTo"] forKey:@"endDate"];
                        }
                        if ([[data allKeys]containsObject:@"isRoundTrip"]) {
                            [tmp setObject:[data objectForKey:@"isRoundTrip"] forKey:@"roundTrip"];
                        }
                        if ([[data allKeys]containsObject:@"durationMin"]) {
                            [tmp setObject:[data objectForKey:@"durationMin"] forKey:@"durationMin"];
                            bugetController.minDays = [[tmp objectForKey:@"durationMin"] intValue];
                        }
                        if ([[data allKeys]containsObject:@"durationMax"]) {
                            [tmp setObject:[data objectForKey:@"durationMax"] forKey:@"durationMax"];
                        }
                        bugetController.data = tmp;
                        [bugetController loadRecommendPrice:tmp];
                        [current.navigationController pushViewController:bugetController animated:YES];
                    }
                    
                }else if ([path isEqualToString:@"/realtime_order_create"]){
                    if (data) {
                        WaitingPayViewController *waitPay = [[WaitingPayViewController alloc]init];
                        NSMutableArray *ids = [[NSMutableArray alloc]init];
                        if ([[data allKeys]containsObject:@"departFlightId"]) {
                            [ids addObject:[data objectForKey:@"departFlightId"]];
                        }
                        if ([[data allKeys]containsObject:@"returnFlightId"]) {
                            [ids addObject:[data objectForKey:@"returnFlightId"]];
                        }
                        
                        if (ids.count>0) {
                            [waitPay loadWithFlightIds:ids];
                            [waitPay setFromPage:WebPage];
                            [waitPay checkPassport:nil to:nil flight:ids];
                            [current.navigationController pushViewController:waitPay animated:YES];
                        }
                        
                    }
                    
                }
                
            }else if([host isEqualToString:@"order"]){
                if (uid) {
                    if ([path isEqualToString:@"/list"]) {
                        OrderViewController *order = [[OrderViewController alloc]init];
                        [order.view setBackgroundColor:[UIColor colorWithHexString:@"#F4F4F4"]];
                        [current.navigationController pushViewController:order animated:YES];
                    }
                    if ([path isEqualToString:@"/detail"]) {
                        if (data) {
                            
                        }
                    }
                }else{
                    [self backToLogin:current];
                }
            }else if([host isEqualToString:@"message"]){
                if (uid) {
                    MessageViewController *msg = [[MessageViewController alloc]init];
                    [current.navigationController pushViewController:msg animated:YES tabBar:YES];
                }else{
                    [self backToLogin:current];
                }
                
                
            }else if([host isEqualToString:@"mine"]){
                if (uid) {
                    [current.tabBarController setSelectedIndex:3];
                    UINavigationController *nav = (UINavigationController*)[current.tabBarController selectedViewController];
                    PersonalViewController *mine = (PersonalViewController*)[nav.viewControllers objectAtIndex:0];
                    if ([path isEqualToString:@"/transactionlist"]) {
                        [mine gotoTradeView];
                    }
                    if ([path isEqualToString:@"/couponlist"]) {
                        [mine gotoCouponView];
                    }
                    if ([path isEqualToString:@"/passengerlist"]) {
                        PassengerViewController *passengerView = [[PassengerViewController alloc]init];
                        [mine.navigationController pushViewController:passengerView animated:YES tabBar:YES];
                    }
                }else{
                    [self backToLogin:current];
                }
                
            }
        }
        
    }
}

+(NSDictionary*)handleSuccessData:(NSDictionary *)data
{
    NSCalendar *calendar = [[NSCalendar alloc]initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"MM-dd"];
    NSDateFormatter *formatter2 = [[NSDateFormatter alloc]init];
    [formatter2 setDateStyle:NSDateFormatterShortStyle];
    [formatter2 setTimeStyle:NSDateFormatterNoStyle];
    [formatter2 setDateFormat:@"HH:mm"];
    
    NSMutableDictionary *diction = [[NSMutableDictionary alloc]init];
    NSMutableArray *array = [[NSMutableArray alloc]init];
    
    NSArray *airlines = [data objectForKey:kOrderReformerKeyAirline];
    for (int i=0; i<[airlines count]; i++) {
        NSDictionary *dic = [airlines objectAtIndex:i];
        NSMutableDictionary *tmpDic = [NSMutableDictionary dictionaryWithDictionary:dic];
        [tmpDic setObject:@"NO" forKey:@"SHOW-TRANSFER"];
        [tmpDic setObject:[NSNumber numberWithInt:i] forKey:@"AIRLINE-NO"];
        
        NSData *imgData = [NSData dataWithContentsOfURL:[NSURL URLWithString:[dic objectForKey:kOrderReformerKeyAirlineInfoCompanyImgURL]]];
        UIImage *icon = [UIImage imageWithData:imgData];
//        icon = [BaseHandler scaleImage:icon scaledToSize:CGSizeMake(icon.size.width/2, icon.size.height/2)];
        if (icon) {
            [tmpDic setObject:icon forKey:@"companyIcon"];
        }
        
        NSDate *airlineDate = [NSDate dateWithTimeIntervalSince1970:[[dic objectForKey:kOrderReformerKeyAirlineInfoDate] longLongValue]/1000];
        
        
        NSDateComponents *comps;
        NSInteger unitFlags =NSYearCalendarUnit | NSMonthCalendarUnit |NSDayCalendarUnit | NSWeekdayCalendarUnit |
        NSHourCalendarUnit |NSMinuteCalendarUnit | NSSecondCalendarUnit;
        comps = [calendar components:unitFlags fromDate:airlineDate];
        NSInteger weekday = [comps weekday];
        NSString *weekDayString = @"";
        switch (weekday) {
            case 1:
                weekDayString = @"周日";
                break;
            case 2:
                weekDayString = @"周一";
                break;
            case 3:
                weekDayString = @"周二";
                break;
            case 4:
                weekDayString = @"周三";
                break;
            case 5:
                weekDayString = @"周四";
                break;
            case 6:
                weekDayString = @"周五";
                break;
            case 7:
                weekDayString = @"周六";
                break;
        }
        
        
        
        NSString *airlineDateStr = [formatter stringFromDate:airlineDate];
        [tmpDic setObject:[NSString stringWithFormat:@"%@ %@",airlineDateStr,weekDayString] forKey:@"goDate"];
        
        NSArray *flight = [dic objectForKey:kOrderReformerKeyAirlineInfoFlight];
        
        NSString *firstFromLoc = @"";
        NSString *secondToLoc = @"";
        NSString *firstToLoc = @"";
        NSString *secondFromLoc = @"";
        NSString *transferString = @"";
        NSString *firstEndDateStr = nil;
        NSString *secondEndDateStr = nil;
        
        if ([flight count]!=0) {
            NSDictionary *firstFlight = [flight objectAtIndex:0];
            NSArray *firstKeys = [firstFlight allKeys];
            if ([firstKeys containsObject:@"flightNo"]) {
                [tmpDic setObject:[NSString stringWithFormat:@"%@",[firstFlight objectForKey:@"flightNo"]] forKey:@"firstAirNo"];
            }else{
                [tmpDic setObject:[NSString stringWithFormat:@"%@",[dic objectForKey:kOrderReformerKeyAirlineInfoFlightNo]] forKey:@"firstAirNo"];
            }
            if ([firstKeys containsObject:@"fromLoc"]) {
                firstFromLoc = [firstFlight objectForKey:@"fromLoc"];
                [tmpDic setObject:firstFromLoc forKey:@"firstStartCity"];
            }
            if([firstKeys  containsObject:@"toLoc"]) {
                firstToLoc = [firstFlight objectForKey:@"toLoc"];
                secondToLoc = firstToLoc;
                [tmpDic setObject:firstToLoc forKey:@"firstEndCity"];
            }
            if([firstKeys  containsObject:@"offAirport"]) {
                [tmpDic setObject:[firstFlight objectForKey:@"offAirport"] forKey:@"firstEndAirport"];
            }
            
            int firstCostHour = 0;
            float firstMinute = 0;
            int firstCostMinute = 0;
            if ([firstKeys  containsObject:@"costTime"]) {
                firstCostHour = (int)[[firstFlight objectForKey:@"costTime"] longLongValue]/1000/60/60;
                firstMinute = (float)[[firstFlight objectForKey:@"costTime"] longLongValue]/1000/60/60 - firstCostHour;
                firstCostMinute = firstMinute*60;
                [tmpDic setObject:[NSString stringWithFormat:@"%d小时%d分钟",firstCostHour,firstCostMinute] forKey:@"firstCostTime"];
            }
            
            
            int totalHour = 0;
            int totalMinute = 0;
            int totalcostMinute = 0;
            
            if ([[data allKeys]containsObject:kOrderReformerKeyAirlineInfoCostTime]) {
                totalHour = (int)[[tmpDic  objectForKey:kOrderReformerKeyAirlineInfoCostTime] longLongValue]/1000/60/60;
                totalMinute = (float)[[tmpDic  objectForKey:kOrderReformerKeyAirlineInfoCostTime] longLongValue]/1000/60/60 - totalHour;
                totalcostMinute = totalMinute*60;
                [tmpDic setObject:[NSString stringWithFormat:@"%d小时%d分钟",totalHour,totalcostMinute] forKey:@"totalCostTime"];
            }
            NSDate *firstStartDate = [NSDate dateWithTimeIntervalSince1970:[[firstFlight  objectForKey:@"onTime"] longLongValue]/1000];
            NSDate *firstEndDate = [NSDate dateWithTimeIntervalSince1970:[[firstFlight  objectForKey:@"offTime"] longLongValue]/1000];
            NSString *firstStartDateStr = [formatter2 stringFromDate:firstStartDate];
            firstEndDateStr = [formatter2 stringFromDate:firstEndDate];
            
            /////////
            
            UInt64 tmpFirstStartDateUint = [firstStartDate timeIntervalSince1970];
            UInt64 tmpFirstEndDateUint = [firstEndDate timeIntervalSince1970];
            
            if ((int)(tmpFirstEndDateUint-tmpFirstStartDateUint)/60/60/24>0) {
                firstEndDateStr = [NSString stringWithFormat:@"%@(+%d)",firstEndDateStr,(int)(tmpFirstEndDateUint-tmpFirstStartDateUint)/60/60/24];
            }
            
            ////////
            
            [tmpDic setObject:firstStartDateStr forKey:@"firstStartDate"];
            [tmpDic setObject:firstEndDateStr forKey:@"firstEndDate"];
            [tmpDic setObject:[firstFlight  objectForKey:@"onAirport"] forKey:@"firstFlightOnAirport"];
            [tmpDic setObject:[firstFlight  objectForKey:@"offAirport"] forKey:@"firstFlightOffAirport"];
            
            
            if ([flight count]>1) {
                NSDictionary *secondFlight = [flight objectAtIndex:1];
                NSArray *secondKeys = [secondFlight allKeys];
                
                if ([secondKeys containsObject:@"fromLoc"]) {
                    secondFromLoc = [secondFlight objectForKey:@"fromLoc"];
                    [tmpDic setObject:secondFromLoc forKey:@"secondFromLoc"];
                    
                }
                if ([secondKeys containsObject:@"toLoc"]) {
                    secondToLoc = [secondFlight objectForKey:@"toLoc"];
                    [tmpDic setObject:secondToLoc forKey:@"secondToLoc"];
                }
                
                [tmpDic setObject:[NSString stringWithFormat:@"%@",[secondFlight objectForKey:@"flightNo"]] forKey:@"secondAirNo"];
                
                int costHour = (int)[[secondFlight  objectForKey:@"costTime"] longLongValue]/1000/60/60;
                float minute = (float)[[secondFlight  objectForKey:@"costTime"] longLongValue]/1000/60/60 - costHour;
                int costMinute = minute*60;
                [tmpDic setObject:[NSString stringWithFormat:@"%d小时%d分钟",costHour,costMinute] forKey:@"secondCostTime"];
                
                NSDate *secondStartDate = [NSDate dateWithTimeIntervalSince1970:[[secondFlight  objectForKey:@"onTime"] longLongValue]/1000];
                NSDate *secondEndDate = [NSDate dateWithTimeIntervalSince1970:[[secondFlight  objectForKey:@"offTime"] longLongValue]/1000];
                NSString *secondStartDateStr = [formatter2 stringFromDate:secondStartDate];
                secondEndDateStr = [formatter2 stringFromDate:secondEndDate];
                
                /////////
                
                UInt64 tmpSecondStartDateUint = [secondStartDate timeIntervalSince1970];
                UInt64 tmpSecondEndDateUint = [secondEndDate timeIntervalSince1970];
                
                if ((int)(tmpSecondEndDateUint-tmpSecondStartDateUint)/60/60/24>0) {
                    secondEndDateStr = [NSString stringWithFormat:@"%@(+%d)",secondEndDateStr,(int)(tmpSecondEndDateUint-tmpSecondStartDateUint)/60/60/24];
                }
                
                ////////
                [tmpDic setObject:secondStartDateStr forKey:@"secondStartTime"];
                [tmpDic setObject:secondEndDateStr forKey:@"secondEndTime"];
                [tmpDic setObject:[secondFlight  objectForKey:@"onAirport"] forKey:@"secondStartAirport"];
                [tmpDic setObject:[secondFlight  objectForKey:@"offAirport"] forKey:@"secondEndAirport"];
                
                int transferHour = (int)([[secondFlight  objectForKey:@"onTime"] longLongValue]/1000 - [[firstFlight  objectForKey:@"offTime"] longLongValue]/1000)/60/60;
                transferString =[NSString stringWithFormat:@"%@中转    %d小时",firstToLoc,transferHour];
                [tmpDic setObject:transferString forKey:@"transfer"];
                
                if ([[data allKeys]containsObject:kOrderReformerKeyAirlineInfoCostTime]) {
                    [tmpDic setObject:[NSString stringWithFormat:@"%d小时%d分钟",totalHour,totalcostMinute] forKey:@"totalCostTime"];
                }else{
                    if ([secondKeys containsObject:@"costTime"]) {
                        long long costTime = [[firstFlight objectForKey:@"costTime"] longLongValue]+[[secondFlight objectForKey:@"costTime"] longLongValue]+[[secondFlight  objectForKey:@"onTime"] longLongValue] - [[firstFlight  objectForKey:@"offTime"] longLongValue];
                        
                        int costHour = (int)(costTime/1000/60/60);
                        float minute = (float)costTime/1000/60/60 - costHour;
                        int costMinute = minute*60;
                        [tmpDic setObject:[NSString stringWithFormat:@"%d小时%d分钟",costHour,costMinute] forKey:@"totalCostTime"];
                    }
                }
                if ([firstKeys containsObject:@"costTime"]) {
                    int costHour = (int)[[firstFlight objectForKey:@"costTime"] longLongValue]/1000/60/60;
                    float minute = (float)[[firstFlight objectForKey:@"costTime"] longLongValue]/1000/60/60 - costHour;
                    int costMinute = minute*60;
                    [tmpDic setObject:[NSString stringWithFormat:@"%d小时%d分钟",costHour,costMinute] forKey:@"firstCostTime"];
                }
            }
        }
        ///////////
        
        [array addObject:@[tmpDic]];
        
    }
    
    [diction setObject:array forKey:@"info"];
    if ([[data allKeys]containsObject:kOrderReformerKeyPassengers]) {
         NSArray *passengers = [data objectForKey:kOrderReformerKeyPassengers];
        [diction setObject:passengers forKey:@"passengers"];
    }
    return diction;
    
    
}

@end
